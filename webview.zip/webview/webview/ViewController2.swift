//
//  ViewController2.swift
//  webview
//
//  Created by Rahul on 16/07/18.
//  Copyright © 2018 Rahul. All rights reserved.
//

import UIKit

class ViewController2: UIViewController {
    
    
    @IBOutlet var webView: UIWebView!
    var passUrl = String()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        print(passUrl)
        let websiteUrl = URL(string: "http://\(passUrl)")//close when open below line
        //let websiteUrl = URL(string: "http://tablet.brainsplurge.co.uk")

        var urlRequest: URLRequest? = nil
        if let anUrl = websiteUrl {
            urlRequest = URLRequest(url: anUrl)
        }
        if let aRequest = urlRequest {
            webView.loadRequest(aRequest)
        }
        
        
        
    }

 
    
    
    
    
    
    
   

}
