//
//  ViewController.swift
//  webview
//
//  Created by Rahul on 16/07/18.
//  Copyright © 2018 Rahul. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

   

    @IBOutlet var txtField: UITextField!
    
    @IBAction func NextBtn(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "ViewController2") as! ViewController2
        vc.passUrl = txtField.text!
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}

